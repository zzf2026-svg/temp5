# Qwen3.5-4B 汽车单案例生成 SFT

每条输入给出一组实际使用的因子，模型输出一个中文案例 JSON 对象。训练只对助手的 JSON 和结束标记计算损失。默认使用已经后训练的 `Qwen/Qwen3.5-4B`，对语言层做 BF16 LoRA。

| 文件 | 用途 |
| --- | --- |
| `train.py` | 校验数据、启动 LoRA、保存检查点和适配器 |
| `common.py` | 数据校验、Qwen 聊天模板和训练标签 |
| `evaluate.py` | 生成验证或测试案例，检查结构和因子覆盖 |
| `datasets/` | 384 条训练、48 条验证、40 条测试及文件校验清单 |

## 1. 离线检查

解压后进入当前目录。以下命令只需要 Python 3.11 或 3.12，不下载模型。校验通过时会显示三个集合的条数，同时检查文件哈希、跨集合重复输入和单案例目标。

```bash
python -B train.py --check-data
```

数据来自已有合成案例，原批次的人工复核状态仍然适用。训练使用 train，训练中的损失监控使用 validation。test 留到配置确定后评估。

## 2. 准备 GPU 环境

使用一张支持原生 BF16 的 NVIDIA CUDA GPU。先按显卡和驱动选择官方 PyTorch CUDA 安装命令。以下 Bash 示例使用已获授权的 Linux 训练盘。把 `/path/on/training-volume` 改成实际绝对路径，先用 `findmnt -T` 和 `df -h` 确认挂载和可用容量。模型权重、Python 环境、临时文件和训练输出需要分别预留空间。

```bash
export CASE_SFT_WORK=/path/on/training-volume/qwen35-single-case
mkdir -p "$CASE_SFT_WORK/cache/pip" "$CASE_SFT_WORK/tmp"
export PIP_CACHE_DIR="$CASE_SFT_WORK/cache/pip"
export TMPDIR="$CASE_SFT_WORK/tmp"
export CUDA_VISIBLE_DEVICES=0
python3 -m venv "$CASE_SFT_WORK/venv"
source "$CASE_SFT_WORK/venv/bin/activate"
# 在这个虚拟环境中先执行与你的驱动匹配的官方 PyTorch CUDA 安装命令。
python -m pip install -r requirements.txt
```

如在 Windows 运行，将工作路径设为 E 盘上已确认可写且容量足够的目录。若从 WSL 使用 E 盘，先确认挂载确实来自 Windows E。训练脚本通过 `--work-dir` 设置 Hugging Face、Torch 和临时目录。可用 `--model /absolute/path/to/checkpoint --local-files-only` 使用现有权重。 [PyTorch 安装指南](https://pytorch.org/get-started/locally/) · [Qwen3.5-4B 官方模型卡](https://huggingface.co/Qwen/Qwen3.5-4B)

## 3. 验证一次训练再正式运行

```bash
python train.py --work-dir "$CASE_SFT_WORK" --run-name smoke --smoke
python train.py --work-dir "$CASE_SFT_WORK" --run-name single-case-lora
```

冒烟模式仅使用 8 条训练和 2 条验证样本，执行 2 个优化步。正式配置为 LoRA rank 16、2 个 epoch、每设备批量 1、梯度累积 8、学习率 1e-4。序列上限为 2048 token，超过时会报出案例 ID，便于保留完整目标。正式训练根据验证损失选择检查点，最终适配器在 `runs/single-case-lora/adapter/`。同名运行目录会被保留。可用 `--revision` 固定 Hub 提交。

## 4. 评估输出

```bash
python evaluate.py --work-dir "$CASE_SFT_WORK" --report-name base-validation.json
python evaluate.py --work-dir "$CASE_SFT_WORK" --report-name lora-validation.json \
  --adapter "$CASE_SFT_WORK/runs/single-case-lora/adapter"
```

报告位于 `reports/`，记录逐条输出、结构校验和因子覆盖结果。方案能否解决痛点由审阅判断。确定配置后，两条命令可用 `--split test` 在测试集上执行，分别指定新的报告名。比较原版和适配器时，两次运行应使用同一份底座权重。
