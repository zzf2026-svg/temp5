"""Run single-GPU BF16 LoRA SFT on the assistant's single-case JSON."""

import argparse
import json
import re
from pathlib import Path

from common import (
    DATA_DIR, MODEL_ID, check_cuda, configure_storage, read_data, training_features,
)


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=DATA_DIR)
    parser.add_argument("--check-data", action="store_true", help="Validate the JSONL on CPU and exit")
    parser.add_argument("--work-dir", type=Path, help="Absolute directory for caches and runs")
    parser.add_argument("--run-name", default="single-case-lora")
    parser.add_argument("--model", default=MODEL_ID, help="Hub ID or local Qwen3.5 checkpoint")
    parser.add_argument("--revision", help="Optional Hub commit hash")
    parser.add_argument("--local-files-only", action="store_true")
    parser.add_argument("--epochs", type=float, default=2)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--gradient-accumulation", type=int, default=8)
    parser.add_argument("--max-length", type=int, default=2048)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--smoke", action="store_true", help="Train for two steps and save an adapter")
    args = parser.parse_args()
    if not args.check_data and not args.work_dir:
        parser.error("--work-dir is required for training")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", args.run_name):
        parser.error("--run-name must be one directory name using letters, digits, dots, _ or -")
    if min(args.epochs, args.learning_rate, args.gradient_accumulation, args.max_length) <= 0:
        parser.error("Training parameters must be positive")
    return args


def pad_batch(batch, tensor, pad_id):
    """Pad labels with -100 even when the pad and end token IDs match."""
    size = max(len(example["input_ids"]) for example in batch)
    inputs, labels, masks = [], [], []
    for example in batch:
        length = len(example["input_ids"])
        padding = size - length
        inputs.append(example["input_ids"] + [pad_id] * padding)
        labels.append(example["labels"] + [-100] * padding)
        masks.append([1] * length + [0] * padding)
    return {"input_ids": tensor(inputs), "labels": tensor(labels), "attention_mask": tensor(masks)}


def main():
    args = arguments()
    splits, manifest = read_data(args.data_dir)
    print(json.dumps({name: len(rows) for name, rows in splits.items()}), flush=True)
    if args.check_data:
        return

    run_dir = configure_storage(args.work_dir) / "runs" / args.run_name
    if run_dir.exists():
        raise SystemExit(f"Run already exists: {run_dir}")

    import accelerate
    import peft
    import torch
    import transformers
    from peft import LoraConfig, TaskType, get_peft_model
    from transformers import (
        AutoConfig, AutoModelForImageTextToText, AutoTokenizer, Trainer, TrainingArguments, set_seed,
    )

    check_cuda(torch)
    set_seed(args.seed)
    load = {"revision": args.revision, "local_files_only": args.local_files_only}
    config = AutoConfig.from_pretrained(args.model, **load)
    if config.model_type != "qwen3_5":
        raise SystemExit(f"Expected a dense Qwen3.5 model, got {config.model_type}")
    load["revision"] = getattr(config, "_commit_hash", None) or args.revision
    tokenizer = AutoTokenizer.from_pretrained(args.model, **load)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    train_rows = splits["train"][:8] if args.smoke else splits["train"]
    validation_rows = splits["validation"][:2] if args.smoke else splits["validation"]
    train_features = training_features(tokenizer, train_rows, args.max_length)
    validation_features = training_features(tokenizer, validation_rows, args.max_length)
    print(f"Longest tokenized example: {max(len(row['input_ids']) for row in train_features + validation_features)}",
          flush=True)

    model = AutoModelForImageTextToText.from_pretrained(
        args.model, config=config, dtype=torch.bfloat16, **load
    )
    model.config.use_cache = False
    model.config.text_config.use_cache = False
    projections = {"q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"}
    targets = [
        name for name, module in model.named_modules()
        if name.startswith("model.language_model.layers.")
        and name.rsplit(".", 1)[-1] in projections
        and isinstance(module, torch.nn.Linear)
    ]
    if not targets:
        raise RuntimeError("No Qwen3.5 language projections found for LoRA")
    model = get_peft_model(model, LoraConfig(
        task_type=TaskType.CAUSAL_LM, r=16, lora_alpha=32, lora_dropout=0.05,
        target_modules=targets, bias="none", revision=load["revision"],
    ))
    model.print_trainable_parameters()

    run_dir.mkdir(parents=True, exist_ok=False)
    run_info = {
        "model": args.model, "revision": load["revision"], "seed": args.seed,
        "smoke": args.smoke, "gpu": torch.cuda.get_device_name(0),
        "versions": {lib.__name__: lib.__version__ for lib in (torch, transformers, peft, accelerate)},
        "arguments": vars(args),
        "dataset_artifacts": manifest["artifacts"],
        "used_records": {"train": len(train_rows), "validation": len(validation_rows)},
    }
    (run_dir / "run.json").write_text(
        json.dumps(run_info, default=str, indent=2) + "\n", encoding="utf-8"
    )
    trainer = Trainer(
        model=model,
        args=TrainingArguments(
            output_dir=str(run_dir / "checkpoints"),
            num_train_epochs=args.epochs,
            max_steps=2 if args.smoke else -1,
            per_device_train_batch_size=1,
            per_device_eval_batch_size=1,
            gradient_accumulation_steps=1 if args.smoke else args.gradient_accumulation,
            learning_rate=args.learning_rate,
            warmup_steps=0 if args.smoke else 0.05,
            optim="adamw_torch",
            bf16=True,
            gradient_checkpointing=True,
            gradient_checkpointing_kwargs={"use_reentrant": False},
            remove_unused_columns=False,
            label_names=["labels"],
            prediction_loss_only=True,
            logging_steps=1 if args.smoke else 5,
            eval_strategy="epoch",
            save_strategy="epoch",
            load_best_model_at_end=not args.smoke,
            metric_for_best_model="eval_loss",
            greater_is_better=False,
            save_total_limit=2,
            report_to="none",
            seed=args.seed,
        ),
        train_dataset=train_features,
        eval_dataset=validation_features,
        processing_class=tokenizer,
        data_collator=lambda batch: pad_batch(batch, torch.tensor, tokenizer.pad_token_id),
    )
    result = trainer.train()
    trainer.save_model(str(run_dir / "adapter"))
    trainer.save_metrics("train", result.metrics)
    print(f"LoRA adapter: {run_dir / 'adapter'}")


if __name__ == "__main__":
    main()
