"""Generate held-out cases and count structural and factor-coverage passes."""

import argparse
import json
from pathlib import Path

from common import (
    DATA_DIR, MODEL_ID, check_cuda, configure_storage, covers_factors, input_factors,
    parse_case, prompt_tokens, read_data,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--report-name", required=True, help="New report filename ending in .json")
    parser.add_argument("--data-dir", type=Path, default=DATA_DIR)
    parser.add_argument("--split", choices=("validation", "test"), default="validation")
    parser.add_argument("--model", help=f"Base model for comparison, defaults to {MODEL_ID}")
    parser.add_argument("--revision", help="Optional base model commit hash")
    parser.add_argument("--adapter", type=Path, help="Saved LoRA directory from train.py")
    parser.add_argument("--local-files-only", action="store_true")
    parser.add_argument("--limit", type=int, help="Evaluate only the first N cases")
    parser.add_argument("--max-new-tokens", type=int, default=768)
    args = parser.parse_args()
    if Path(args.report_name).name != args.report_name or not args.report_name.endswith(".json"):
        parser.error("--report-name must be a filename ending in .json")
    if args.max_new_tokens < 1 or (args.limit is not None and args.limit < 1):
        parser.error("Token and sample limits must be positive")

    splits, manifest = read_data(args.data_dir)
    report = configure_storage(args.work_dir) / "reports" / args.report_name
    if report.exists():
        raise SystemExit(f"Report already exists: {report}")

    import torch
    from peft import PeftConfig, PeftModel
    from transformers import AutoConfig, AutoModelForImageTextToText, AutoTokenizer, GenerationConfig

    check_cuda(torch)
    model_id = args.model or MODEL_ID
    revision = args.revision
    if args.adapter:
        adapter_config = PeftConfig.from_pretrained(str(args.adapter), local_files_only=True)
        if not args.model:
            model_id = adapter_config.base_model_name_or_path
        if not revision and model_id == adapter_config.base_model_name_or_path:
            revision = adapter_config.revision
    load = {"revision": revision, "local_files_only": args.local_files_only}
    config = AutoConfig.from_pretrained(model_id, **load)
    if config.model_type != "qwen3_5":
        raise SystemExit(f"Expected a dense Qwen3.5 model, got {config.model_type}")
    load["revision"] = getattr(config, "_commit_hash", None) or revision
    tokenizer = AutoTokenizer.from_pretrained(model_id, **load)
    model = AutoModelForImageTextToText.from_pretrained(
        model_id, config=config, dtype=torch.bfloat16, **load
    ).to("cuda")
    if args.adapter:
        model = PeftModel.from_pretrained(model, str(args.adapter), local_files_only=True)
    model.eval()
    generation = GenerationConfig(
        max_new_tokens=args.max_new_tokens, do_sample=False,
        eos_token_id=tokenizer.eos_token_id,
        pad_token_id=tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id,
    )

    results = []
    with torch.inference_mode():
        for row in splits[args.split][:args.limit]:
            messages = row["messages"]
            factors = input_factors(messages)
            ids = torch.tensor([prompt_tokens(tokenizer, messages)], device="cuda")
            sequence = model.generate(
                input_ids=ids, attention_mask=torch.ones_like(ids), generation_config=generation
            )[0, ids.shape[1]:]
            response = tokenizer.decode(sequence, skip_special_tokens=True)
            case = None
            try:
                case = parse_case(response)
            except ValueError as exc:
                error = str(exc)
            else:
                error = None if covers_factors(case, factors) else "Missing or additional factors"
            results.append({
                "id": row["id"], "factors": factors, "response": response,
                "structure_pass": case is not None, "factor_pass": error is None,
                "issue": error, "reference_case": json.loads(messages[-1]["content"]),
            })

    counts = {
        "generated": len(results),
        "structure_pass": sum(result["structure_pass"] for result in results),
        "structure_and_factor_pass": sum(result["factor_pass"] for result in results),
    }
    report.parent.mkdir(parents=True, exist_ok=True)
    with report.open("x", encoding="utf-8") as stream:
        json.dump({
            "model": model_id, "revision": load["revision"], "adapter": str(args.adapter) if args.adapter else None,
            "split": args.split, "dataset": manifest["artifacts"][f"{args.split}.jsonl"],
            "max_new_tokens": args.max_new_tokens, "counts": counts, "cases": results,
        }, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(json.dumps(counts))
    print(f"Report: {report}")


if __name__ == "__main__":
    main()
