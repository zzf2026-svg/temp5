"""Read the single-case dataset and prepare Qwen chat tokens."""

import hashlib
import json
import os
from pathlib import Path


MODEL_ID = "Qwen/Qwen3.5-4B"
DATA_DIR = Path(__file__).resolve().parent / "datasets"
TASK = "GENERATE_SINGLE_FUNCTION_CASE"
CASE_FIELDS = {"核心元素", "场景描述", "痛点分析", "解决方案", "涉及领域"}
SPLITS = ("train", "validation", "test")


def valid_string_list(value):
    return (
        isinstance(value, list)
        and bool(value)
        and all(isinstance(item, str) and item.strip() for item in value)
        and len(set(value)) == len(value)
    )


def parse_case(text):
    label = json.loads(text)
    if not isinstance(label, dict) or set(label) != CASE_FIELDS:
        raise ValueError("Expected one case object with the five required fields")
    for field in ("核心元素", "涉及领域"):
        if not valid_string_list(label[field]):
            raise ValueError(f"Invalid string list: {field}")
    for field, limit in (("场景描述", 80), ("痛点分析", 50), ("解决方案", None)):
        value = label[field]
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"Missing text: {field}")
        if limit is not None and len(value) > limit:
            raise ValueError(f"Text exceeds {limit} characters: {field}")
    return label


def input_factors(messages):
    _, separator, factor_json = messages[1]["content"].partition("\n")
    if not separator:
        raise ValueError("The user message must end with a line containing its JSON factor list")
    factors = json.loads(factor_json)
    if not valid_string_list(factors):
        raise ValueError("Expected a non-empty list of distinct factors")
    return factors


def covers_factors(case, factors):
    body = case["场景描述"] + case["痛点分析"] + case["解决方案"]
    return set(case["核心元素"]) == set(factors) and all(factor in body for factor in factors)


def read_data(data_dir):
    manifest = json.loads((data_dir / "manifest.json").read_text(encoding="utf-8"))
    if manifest["task_type"] != TASK:
        raise ValueError("Dataset manifest must identify the single-case task")

    splits = {}
    seen_ids = set()
    group_splits = {}
    input_splits = {}
    for split in SPLITS:
        path = data_dir / f"{split}.jsonl"
        raw = path.read_bytes()
        expected = manifest["artifacts"][path.name]
        if hashlib.sha256(raw).hexdigest() != expected["sha256"]:
            raise ValueError(f"SHA-256 mismatch: {path}")
        rows = []
        for line_number, line in enumerate(raw.decode("utf-8").splitlines(), 1):
            try:
                row = json.loads(line)
                messages = row["messages"]
                meta = row["metadata"]
                if row["task_type"] != TASK or meta["split"] != split:
                    raise ValueError("Unexpected task or split")
                if [message["role"] for message in messages] != ["system", "user", "assistant"]:
                    raise ValueError("Expected exactly system, user and assistant messages")
                if not all(isinstance(message["content"], str) and message["content"].strip()
                           for message in messages):
                    raise ValueError("Every message must contain non-empty text")
                if row["id"] in seen_ids:
                    raise ValueError("Duplicate case ID")
                seen_ids.add(row["id"])
                factors = input_factors(messages)
                label = parse_case(messages[-1]["content"])
                if not covers_factors(label, factors):
                    raise ValueError("Case does not cover the supplied factors")
                if group_splits.setdefault(meta["split_group_id"], split) != split:
                    raise ValueError("Original case group crosses splits")
                if input_splits.setdefault(tuple(sorted(factors)), split) != split:
                    raise ValueError("Identical factor input crosses splits")
            except (ValueError, TypeError, KeyError) as exc:
                raise ValueError(f"{path}:{line_number}: {exc}") from exc
            rows.append(row)
        if not rows or len(rows) != expected["records"]:
            raise ValueError(f"Unexpected record count: {path}")
        splits[split] = rows
    if len(seen_ids) != manifest["records"]:
        raise ValueError("Record count does not match manifest")
    return splits, manifest


def prompt_tokens(tokenizer, messages):
    prompt = tokenizer.apply_chat_template(
        messages[:2], tokenize=False, add_generation_prompt=True, enable_thinking=False
    )
    return tokenizer(prompt, add_special_tokens=False)["input_ids"]


def training_features(tokenizer, rows, max_length):
    end_ids = tokenizer("<|im_end|>", add_special_tokens=False)["input_ids"]
    if end_ids != [tokenizer.eos_token_id] or tokenizer.eos_token_id is None:
        raise ValueError("Expected the Qwen assistant turn terminator <|im_end|>")
    features = []
    for row in rows:
        messages = row["messages"]
        prompt_ids = prompt_tokens(tokenizer, messages)
        answer_ids = tokenizer(messages[-1]["content"], add_special_tokens=False)["input_ids"]
        input_ids = prompt_ids + answer_ids + end_ids
        if not prompt_ids or not answer_ids:
            raise ValueError(f"Empty prompt or completion tokens: {row['id']}")
        if len(input_ids) > max_length:
            raise ValueError(
                f"{row['id']} has {len(input_ids)} tokens, above --max-length={max_length}. "
                "Increase the limit to retain the complete case and end token."
            )
        features.append({
            "input_ids": input_ids,
            "labels": [-100] * len(prompt_ids) + answer_ids + end_ids,
        })
    return features


def configure_storage(work_dir):
    root = work_dir.resolve()
    if not work_dir.is_absolute():
        raise ValueError("--work-dir must be an absolute path on the intended storage volume")
    locations = {
        "HF_HOME": root / "cache" / "huggingface",
        "HF_HUB_CACHE": root / "cache" / "huggingface" / "hub",
        "HF_XET_CACHE": root / "cache" / "huggingface" / "xet",
        "HF_ASSETS_CACHE": root / "cache" / "huggingface" / "assets",
        "TORCH_HOME": root / "cache" / "torch",
        "TMPDIR": root / "tmp",
        "TMP": root / "tmp",
        "TEMP": root / "tmp",
    }
    for variable, folder in locations.items():
        folder.mkdir(parents=True, exist_ok=True)
        os.environ[variable] = str(folder)
    return root


def check_cuda(torch):
    if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported(including_emulation=False):
        raise SystemExit("This BF16 LoRA recipe requires a CUDA GPU with native BF16 support.")
    if torch.cuda.device_count() != 1 or int(os.environ.get("WORLD_SIZE", "1")) != 1:
        raise SystemExit("Expose exactly one GPU with CUDA_VISIBLE_DEVICES and run with python.")
